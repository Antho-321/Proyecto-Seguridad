<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />
    <link rel="stylesheet" type="text/css" href="../styles/estilo_IngresoDeProductos.css" id="estilo">
    <title>Ingreso de productos</title>
</head>

<body>
    <h1 align="center">Actualización de productos</h1>
    <section id="seccion_principal">
        <div id="seccion__Izq">
            <div>
                <div class="fila">
                    <label class="col" for="lista_categoría">Categoría:</label>
                    <select name="lista_categoría" id="lista_categoría" class="col">
                        <option value="nueva_cat">Nueva categoría</option>
                        <option value="saab">Bodas</option>
                        <option value="opel">Bautizos</option>
                        <option value="audi">XV años</option>
                        <option value="audi">Cumpleaños</option>
                        <option value="audi">Baby Shower</option>
                        <option value="audi">San Valentin</option>
                        <option value="audi">Vísperas de Santos</option>
                        <option value="audi">Navidad</option>
                    </select>
                    <p class="col">Nombre de categoría:</p>
                    <input class="col" type="text">
                </div>
                
                <div class="fila">
                <div class="dropzone" id="formDrop">
            <input type="url" placeholder="Ingresar enlace" id="ingreso_enlace" onclick="ingresarEnlace()">
            <input type="hidden" name="enlace" id="aux_IngresarEnlace">
            <input type="hidden" name='ingreso_enlace' id="verificacion_enlace">
        </div>
                </div>
                
            </div>
            <div class="tabla_info">
                <div class="fila">
                    <p class="col">Forma:</p>
                    <div class="col">
                        <input class="col" type="radio" id="circular">
                        <label for="circular">Circular</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="cuadrada">
                        <label for="cuadrada">Cuadrada</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="rectangular">
                        <label for="rectangular">Rectangular</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="personalizada">
                        <label for="personalizada">Personalizada</label>
                    </div>
                </div>
                <div class="fila">
                    <p class="col">Tamaño:</p>
                    <div class="col">
                        <input class="col" type="radio" id="mini">
                        <label for="mini">Mini (5-6 porciones)</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="pequeña">
                        <label for="pequeña">Pequeña (10-12 porciones)</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="mediana">
                        <label for="mediana">Mediana (16 porciones)</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="grande">
                        <label for="grande">Grande (30 porciones)</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="extra_grande">
                        <label for="extra_grande">Extra grande (70 porciones)</label>
                    </div>
                </div>
                <div class="fila">
                    <p class="col">Masa:</p>
                    <div class="col">
                        <input class="col" type="radio" id="mini">
                        <label for="mini">Normal (Con receta propia)</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="pequeña">
                        <label for="pequeña">Bizcochuelo</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="mediana">
                        <label for="mediana">Milhojas</label>
                    </div>
                </div>
                <div class="fila">
                    <p class="col">Sabor:</p>
                    <div class="col">
                        <input class="col" type="radio" id="mini">
                        <label for="mini">Naranja</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="pequeña">
                        <label for="pequeña">Chocolate</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="mediana">
                        <label for="mediana">Naranja y chocolate (Marmoleada)</label>
                    </div>
                </div>
                <div class="fila">
                    <p class="col">Cobertura:</p>
                    <div class="col">
                        <input class="col" type="radio" id="mini">
                        <label for="mini">Crema</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="pequeña">
                        <label for="pequeña">Fondant</label>
                    </div>
                </div>
                <div class="fila">
                    <p class="col">Relleno:</p>
                    <div class="col">
                        <input class="col" type="radio" id="mini">
                        <label for="mini">Mermelada de frutilla</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="pequeña">
                        <label for="pequeña">Mermelada de mora</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="mediana">
                        <label for="mediana">Glass de frutilla con crema</label>
                    </div>
                    <div class="col">
                        <input class="col" type="radio" id="mediana">
                        <label for="mediana">Crema napolitana</label>
                    </div>
                </div>
            </div>
            <div>
                <div class="fila">
                    <label class="col" for="lista_categoría">Precio:</label>
                    <div class="col">
                        <label for="">$</label>
                        <input type="number"  step="0.1">
                    </div>
                </div>          
                <div class="fila">
                    <p class="col">Descripción adicional:</p>
                    <textarea class="col" name="" id="">(Opcional)</textarea>
                </div>
                
            </div>
        </div>
        <div id="seccion__Der">
            <h2>Previsualización de producto:</h2>
            <img src="../iconos/imagenes.png" alt="Imagen de pastel">
            <div>
                <p>¿Muestra un personaje específco?</p>
                <div>
                    <input class="col" type="radio" id="mediana">
                    <label for="mediana">Sí</label>
                </div>
                <div>
                    <input class="col" type="radio" id="mediana">
                    <label for="mediana">No</label>
                </div>
            </div>
            <div>
                <label for="nombre_personaje">Nombre del personaje:</label>
                <input type="text" id="nombre_personaje">
            </div>
        </div>
    </section>
    <div id="seccion_btn">
        <input type="submit" value="Guardar cambios">
    </div>

</body>

</html>